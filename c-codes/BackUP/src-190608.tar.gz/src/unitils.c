/* ===============================================
 * File Name: unitils.c
 * Author: ekli
 * mail: ekli_091@mail.dlut.edu.cn
 * Created Time: 2019-05-16 16:31:13
 * =============================================== 
 */

#include <stdio.h>

int 
