/* ===============================================
 * File Name: unitils.h
 * Author: ekli
 * mail: ekli_091@mail.dlut.edu.cn
 * Created Time: 2019-05-16 16:15:44
 * =============================================== 
 */

#ifndef _UNITILS_H_
#define _UNITILS_H_

#include <stdio.h>
#include <stdlib.h>

#define class_malloc(type, size) (            \
    (type*)malloc( (size) * (sizeof(type)) )  \
        )

#endif /* _UNITILS_H_*/
